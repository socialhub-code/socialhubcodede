SOCIALHUB MEDIA — WEB 5.0 FINAL

Mở index.html để xem website.

Đã tích hợp:
- Giao diện futuristic / glass / neon / responsive
- Hero động với hiệu ứng pulse, nền grid, orbit và các bubble nền tảng
- Social Media & Truyền thông
- Facebook, Instagram, TikTok, Zalo, Telegram
- AI Content Intelligence, Real-time Analytics, Social Listening, Automation
- 8 nhóm dịch vụ
- Case Study
- KPI
- Quy trình 8 bước
- Liên hệ Zalo 0707789495
- Email kimzorlopthai@gmail.com
- Nút email và nút Zalo có thể bấm

LƯU Ý:
Các số liệu KPI và một số tên case study đang là dữ liệu mẫu. Hãy thay bằng dữ liệu thực tế trước khi công bố.
